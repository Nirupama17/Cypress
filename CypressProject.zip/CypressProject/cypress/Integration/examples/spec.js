describe('Prestashop Web Store Tests', () => {
  
  beforeEach(() => {
    cy.visit('prestashop.ryviushop.com')
  })
  
  it('Displays seven popular products by default', () => {
    cy.get('#homefeatured .left-block > .product-image-container')
    cy.wait(3000)
    cy.get('.product-image-container:visible').should('have.length', 7)
  });
  
  it('Returns the correct result when the user searches for "blouse"', () => {
    cy.get('#searchbox').type('blouse')
    cy.get('button[name="submit_search"]').click()
    cy.get('.page-heading').should('contain', 'blouse')

    //Validating whether clicked product is 'Blouse'
    cy.get('.right-block > h5 > .product-name').should('contain', 'Blouse')
  });
  
  
  it('Informs the user there is 1 item in their cart', () => {
    cy.get('#searchbox').type('blouse')
    cy.get('button[name="submit_search"]').click()
    cy.get('.ajax_add_to_cart_button > span').click()
    cy.get('.heading-counter').should('contain', '1 product')
  });
  
});
